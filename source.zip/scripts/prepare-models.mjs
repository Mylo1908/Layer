import {access,cp,mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
try{await access('public/models/resources.json');}catch{
 try{await access('dist/models/resources.json');await mkdir('public/models',{recursive:true});await cp('dist/models','public/models',{recursive:true});console.log('KI-Dateien aus dem fertigen Build übernommen.');}
 catch{const result=spawnSync(process.execPath,['scripts/download-models.mjs'],{stdio:'inherit'});if(result.status!==0)process.exit(result.status??1);}
}
