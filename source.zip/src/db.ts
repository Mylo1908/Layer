import {OUTLINES} from './collage-outline';
import {garmentAttributes} from './garment-attributes';
import {validatePurchase} from './purchase';
import {validateCalendarEntry,entryFromOutfit,setWorn,localDay,type OutfitCalendarEntry} from './calendar';
import {validatePhotos} from './photos';
import {validAccessory} from './accessories';
import {TEMPLATES} from './collage';
import {visualDetails} from './visual-details';
import {normalizeGarment,SEASONS,LAYERING} from './garment-details';
import { openDB, type DBSchema,type IDBPDatabase } from 'idb';
import { CATEGORIES, type Garment, type Outfit, type Backup,type Collage } from './types';
interface WardrobeDB extends DBSchema { garments:{key:string;value:Garment}; outfits:{key:string;value:Outfit};collages:{key:string;value:Collage};calendarEntries:{key:string;value:OutfitCalendarEntry}; }
const db=()=>new Promise<IDBPDatabase<WardrobeDB>>((resolve,reject)=>{let connection:IDBPDatabase<WardrobeDB>|undefined,blocked=false;void openDB<WardrobeDB>('layer-wardrobe',3,{upgrade(d){if(!d.objectStoreNames.contains('calendarEntries'))d.createObjectStore('calendarEntries',{keyPath:'id'});if(!d.objectStoreNames.contains('garments'))d.createObjectStore('garments',{keyPath:'id'});if(!d.objectStoreNames.contains('outfits'))d.createObjectStore('outfits',{keyPath:'id'});if(!d.objectStoreNames.contains('collages'))d.createObjectStore('collages',{keyPath:'id'});},blocked(){blocked=true;reject(Error('Datenbank-Update wartet: Bitte andere geöffnete Layer-Tabs schließen und die App neu laden. Deine Daten bleiben erhalten.'));},blocking(){connection?.close();}}).then(d=>{connection=d;if(blocked)d.close();else resolve(d);},reject);});
export async function getAll(){const d=await db(); return {garments:(await d.getAll('garments')).map(normalizeGarment),outfits:await d.getAll('outfits'),collages:await d.getAll('collages'),calendarEntries:await d.getAll('calendarEntries')};}
export async function saveGarment(g:Garment){const d=await db();validatePhotos(g);validatePurchase(g);garmentAttributes(g);const {purchasePriceInput,...clean}=g as Garment & {purchasePriceInput?:string};await d.put('garments',normalizeGarment(clean));}
export async function toggleFavorite(id:string){const d=await db();const tx=d.transaction('garments','readwrite');const g=await tx.store.get(id);if(!g)throw Error('Kleidungsstück nicht gefunden.');const favorite=!g.favorite;await tx.store.put({...g,favorite});await tx.done;return favorite;}
export async function saveCollage(c:Collage){validateCollage(c);const d=await db();await d.put('collages',c);}
export async function deleteCollage(id:string){const d=await db();await d.delete('collages',id);}
export async function saveOutfit(o:Outfit){const d=await db();await d.put('outfits',o);}
export async function deleteOutfit(id:string){const d=await db();await d.delete('outfits',id);}
export async function deleteGarment(id:string){const d=await db();const tx=d.transaction(['garments','outfits'],'readwrite');const outfits=await tx.objectStore('outfits').getAll();for(const o of outfits){o.layers=o.layers.filter(l=>l.garmentId!==id);await tx.objectStore('outfits').put(o);}await tx.objectStore('garments').delete(id);await tx.done;}
export function blobData(b:Blob):Promise<string>{return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result as string);r.onerror=()=>reject(r.error);r.readAsDataURL(b);});}
export function dataBlob(s:string){const match=/^data:(image\/(?:png|jpeg|webp|heic|heif|avif|gif|bmp));base64,([A-Za-z0-9+/=\r\n]+)$/.exec(s);if(!match)throw Error('Ungültiges Bild im Backup.');const raw=atob(match[2]);return new Blob([Uint8Array.from(raw,c=>c.charCodeAt(0))],{type:match[1]});}
export async function exportBackup(){const all=await getAll();const garments=[];for(const g of all.garments)garments.push({...g,image:await blobData(g.image),original:await blobData(g.original),processed:await blobData(g.processed),photos:g.photos?await Promise.all(g.photos.map(async p=>({...p,image:await blobData(p.image),source:p.source?await blobData(p.source):undefined}))):undefined});return {format:'layer-wardrobe',version:1,garments,outfits:all.outfits,collages:all.collages,calendarEntries:all.calendarEntries} satisfies Backup;}
const finite=(n:unknown)=>typeof n==='number'&&Number.isFinite(n);
const str=(v:unknown,max=10000)=>typeof v==='string'&&v.length<=max;
export function validateBackup(data:unknown):Backup {
 if(!data||typeof data!=='object')throw Error('Keine gültige Sicherung.');const b=data as Backup;
 if(b.format!=='layer-wardrobe'||b.version!==1||!Array.isArray(b.garments)||!Array.isArray(b.outfits)||b.garments.length>5000||b.outfits.length>5000)throw Error('Nicht unterstützte Sicherung.');
 const ids=new Set<string>();for(const g of b.garments){if(!g||!str(g.id,100)||ids.has(g.id)||!str(g.name,200)||!CATEGORIES.includes(g.category)||!str(g.color,40)||!str(g.season,40)||!str(g.notes)||typeof g.favorite!=='boolean'||!finite(g.createdAt))throw Error('Fehlerhafte Kleidungsdaten.');if(g.seasons!==undefined&&(!Array.isArray(g.seasons)||!g.seasons.length||g.seasons.length>5||g.seasons.some(s=>!SEASONS.includes(s))))throw Error('Ungültige Saison-Auswahl.');if(g.layering!==undefined&&!Object.hasOwn(LAYERING,g.layering))throw Error('Ungültiges Layering.');if(g.userHints!==undefined&&!str(g.userHints,1000)||g.description!==undefined&&!str(g.description,3000))throw Error('Ungültige Kleidungsbeschreibung.');validatePurchase(g);garmentAttributes(g);validatePhotos({...g,photos:g.photos?.map(p=>({...p,image:dataBlob(p.image),source:p.source?dataBlob(p.source):undefined}))});visualDetails(g);if(g.accessoryType!==undefined&&!validAccessory(g.accessoryType))throw Error('Ungültiger Accessoire-Typ.');ids.add(g.id);dataBlob(g.image);dataBlob(g.original);dataBlob(g.processed);}
 const outfitIds=new Set<string>();for(const o of b.outfits){if(!o||!str(o.id,100)||outfitIds.has(o.id)||!str(o.name,200)||!str(o.notes)||!/^#[0-9a-f]{6}$/i.test(o.background)||!finite(o.createdAt)||!finite(o.updatedAt)||!Array.isArray(o.layers)||o.layers.length>100)throw Error('Fehlerhafte Outfitdaten.');outfitIds.add(o.id);const layerIds=new Set<string>();for(const l of o.layers){if(!l||!str(l.id,100)||layerIds.has(l.id)||!ids.has(l.garmentId)||![l.x,l.y,l.width,l.rotation].every(finite)||l.width<10||l.width>1200||Math.abs(l.x)>1200||Math.abs(l.y)>1500||Math.abs(l.rotation)>360||typeof l.locked!=='boolean')throw Error('Fehlerhafte Ebenen.');layerIds.add(l.id);}}
 if(b.collages!==undefined){if(!Array.isArray(b.collages)||b.collages.length>5000)throw Error('Ungültige Collagen.');const seen=new Set<string>();for(const c of b.collages){validateCollage(c);if(seen.has(c.id))throw Error('Doppelte Collage-ID.');seen.add(c.id);}}
 if(b.calendarEntries!==undefined){if(!Array.isArray(b.calendarEntries)||b.calendarEntries.length>50000)throw Error('Ungültige Kalendereinträge.');const seen=new Set<string>();for(const e of b.calendarEntries){validateCalendarEntry(e);if(seen.has(e.id))throw Error('Doppelte Kalender-ID.');seen.add(e.id);}}
 return b;
}
export async function importBackup(data:unknown){
 const b=validateBackup(data);
 // Decode all image fields before starting a transaction; synchronous failures must not commit a prefix.
 const garments=b.garments.map(g=>normalizeGarment({...g,image:dataBlob(g.image),original:dataBlob(g.original),processed:dataBlob(g.processed),photos:g.photos?.map(p=>({...p,image:dataBlob(p.image),source:p.source?dataBlob(p.source):undefined}))}));
 const d=await db(),tx=d.transaction(['garments','outfits','collages','calendarEntries'],'readwrite');
 try{for(const g of garments)await tx.objectStore('garments').put(g);for(const o of b.outfits)await tx.objectStore('outfits').put(o);for(const c of b.collages??[])await tx.objectStore('collages').put(c);for(const e of b.calendarEntries??[])await tx.objectStore('calendarEntries').put(e);await tx.done;return b.garments.length;}
 catch(error){try{tx.abort();}catch{}await tx.done.catch(()=>{});throw error;}
}

export function validateCollage(c:Collage){if(!c||!str(c.id,100)||!c.id||!str(c.name,200)||!c.name.trim()||!TEMPLATES.includes(c.template)||c.outline!==undefined&&!OUTLINES.includes(c.outline)||c.variant!==undefined&&(!Number.isInteger(c.variant)||c.variant<0||c.variant>9999)||!str(c.notes)||!/^#[0-9a-f]{6}$/i.test(c.background)||!finite(c.createdAt)||!finite(c.updatedAt)||c.outfitId!==undefined&&!str(c.outfitId,100)||!Array.isArray(c.layers)||c.layers.length>100)throw Error('Ungültige Collage.');const ids=new Set<string>();for(const l of c.layers){if(!l||!str(l.id,100)||ids.has(l.id)||!str(l.garmentId,100)||![l.x,l.y,l.width,l.rotation].every(finite)||l.width<10||l.width>1200||Math.abs(l.x)>1200||Math.abs(l.y)>1800||Math.abs(l.rotation)>360||typeof l.locked!=='boolean')throw Error('Ungültige Collage-Ebene.');ids.add(l.id);}}

export async function saveCalendarEntry(e:OutfitCalendarEntry){validateCalendarEntry(e);const d=await db();await d.put('calendarEntries',e);}
export async function deleteCalendarEntry(id:string){const d=await db();await d.delete('calendarEntries',id);}
// Transactionally reuse today's assignment: repeated clicks cannot create another wear record.
export async function wearToday(outfit:Outfit,date=localDay(),now=Date.now()){const d=await db(),tx=d.transaction('calendarEntries','readwrite');const all=await tx.store.getAll();const matches=all.filter(e=>e.date===date&&e.outfitId===outfit.id);const existing=matches.find(e=>e.status==='worn')??matches.find(e=>e.status==='planned');const e=existing?.status==='worn'?existing:setWorn(existing??entryFromOutfit(outfit,date,crypto.randomUUID(),now),true,now);validateCalendarEntry(e);await tx.store.put(e);await tx.done;return e;}
