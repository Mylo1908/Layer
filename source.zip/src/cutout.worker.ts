import {removeBackground} from '@imgly/background-removal';
// The whole inference runs off the UI thread; photos never leave the browser.
self.onmessage=async(event:MessageEvent<{image:Blob;publicPath:string}>)=>{
 try {const blob=await removeBackground(event.data.image,{publicPath:event.data.publicPath,model:'isnet_quint8',device:'cpu',proxyToWorker:false,output:{format:'image/png'},progress:(key,current,total)=>self.postMessage({progress:total>0?`${key.startsWith('fetch:')?'KI-Dateien laden':'Freistellen'} · ${Math.round(current/total*100)} %`:'KI arbeitet …'})});self.postMessage({blob});}
 catch(e){self.postMessage({error:e instanceof Error?e.message:String(e)});}
};
